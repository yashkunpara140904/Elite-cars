/* ===== Admin panel logic (front-end only; data lives in memory) ===== */
const apage = document.body.dataset.page;
const MENU = [['Dashboard','dashboard.html','🏠','dashboard'],['Cars','cars.html','🚗','cars'],['Bookings','bookings.html','📅','bookings'],['Test Drives','#','🎯','td'],['Customers','customers.html','👥','customers'],['Services','#','🔧','svc'],['Payments','#','💳','pay'],['Reports','reports.html','📊','reports'],['Messages','#','✉️','msg'],['Users & Roles','#','👤','users'],['Settings','#','⚙️','set']];

function adminLayout() {
  const side = document.createElement('aside');
  side.className = 'sidebar';
  side.innerHTML = `<a class="logo" href="dashboard.html"><span class="logo-ic">🚗</span><span><b>ELITE</b><small>CARS</small></span></a>
    <nav>${MENU.map(m => `<a href="${m[1]}" class="${m[3] === apage ? 'active' : ''}" data-soon="${m[1] === '#'}"><span>${m[2]} &nbsp;${m[0]}</span><span>›</span></a>`).join('')}</nav>
    <div class="me"><div class="avatar">A</div><div><b>Admin</b><br>Super Administrator</div></div>`;
  const main = document.createElement('div');
  main.className = 'main';
  const content = $('main');
  content.className = 'content';
  main.innerHTML = `<div class="topbar"><button class="ic" id="menuBtn">☰</button><div class="top-r"><span class="bell">🔔<i>3</i></span><span>👤 <b>Admin</b> ▾</span><a class="btn light sm" href="login.html">Logout</a></div></div>`;
  main.appendChild(content);
  main.insertAdjacentHTML('beforeend', `<footer class="admin-foot"><span>© 2026 Elite Cars. All Rights Reserved.</span><span>Version 1.0.0 &nbsp;|&nbsp; Support: +91 98765 43210 &nbsp;|&nbsp; info@elitecars.com</span></footer>`);
  document.body.prepend(main); document.body.prepend(side);
  $('#menuBtn').onclick = () => innerWidth <= 800 ? side.classList.toggle('show') : document.body.classList.toggle('collapsed');
  $$('[data-soon="true"]', side).forEach(a => a.onclick = e => { e.preventDefault(); toast('This module is not part of the demo'); });
}

/* ---------- charts (plain SVG / CSS, no libraries) ---------- */
function lineChart(el, labels, series, o = {}) {
  const W = 620, H = 270, L = 40, R = 28, T = 14, B = 34, max = o.max || 100;
  const x = i => L + (W - L - R) * i / (labels.length - 1), y = v => T + (H - T - B) * (1 - v / max);
  let s = `<svg class="line" viewBox="0 0 ${W} ${H}">`;
  for (let i = 0; i <= 5; i++) { const v = max / 5 * i; s += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="#eee"/><text x="${L - 8}" y="${y(v) + 4}" font-size="11" text-anchor="end" fill="#666">${o.fmt ? o.fmt(v) : v}</text>`; }
  labels.forEach((l, i) => s += `<text x="${x(i)}" y="${H - 10}" font-size="11" text-anchor="middle" fill="#666">${l}</text>`);
  series.forEach(se => {
    const pts = se.v.map((v, i) => `${x(i)},${y(v)}`).join(' ');
    if (o.area) s += `<polygon points="${L},${y(0)} ${pts} ${x(labels.length - 1)},${y(0)}" fill="${se.c}" opacity=".18"/>`;
    s += `<polyline points="${pts}" fill="none" stroke="${se.c}" stroke-width="2.5"/>` + se.v.map((v, i) => `<circle cx="${x(i)}" cy="${y(v)}" r="4" fill="${se.c}"><title>${labels[i]}: ${v}</title></circle>`).join('');
  });
  el.innerHTML = (o.legend === false ? '' : `<div class="legend">${series.map(se => `<span><i style="background:${se.c}"></i>${se.n}</span>`).join('')}</div>`) + s + '</svg>';
}
function donut(el, items, colors) {
  const tot = items.reduce((a, b) => a + b[1], 0); let acc = 0;
  const grad = items.map((it, i) => { const a = acc / tot * 100; acc += it[1]; return `${colors[i]} ${a}% ${acc / tot * 100}%`; }).join(',');
  el.innerHTML = `<div class="donut-wrap"><div class="donut" style="background:conic-gradient(${grad})"></div><div class="lg">${items.map((it, i) => `<div><i style="background:${colors[i]}"></i>${it[0]} (${Math.round(it[1] / tot * 100)}%)<b>${it[1]}</b></div>`).join('')}</div></div>`;
}
const DAYS = ['May 14', 'May 15', 'May 16', 'May 17', 'May 18', 'May 19', 'May 20'];
const kpi = (ic, l, v, d, dn) => `<div class="card kpi"><div class="ic">${ic}</div><div><small>${l}</small><b>${v}</b><em class="${dn ? 'dn' : ''}">${dn ? '↓' : '↑'} ${d} from last week</em></div></div>`;
const STATUS_COUNTS = [['Confirmed', 74], ['Pending', 32], ['Cancelled', 13], ['Completed', 9]];

/* ---------- generic table + add/edit/view/delete ---------- */
function formField(f, val) {
  const id = 'm_' + f.n, req = (f.r || '').includes('required') ? ' *' : '';
  const ctl = f.o
    ? `<select id="${id}" data-rules="${f.r || ''}"><option value="">Select</option>${f.o.map(o => `<option ${o == val ? 'selected' : ''}>${o}</option>`).join('')}</select>`
    : `<input id="${id}" type="${f.t || 'text'}" value="${esc(val ?? '')}" data-rules="${f.r || ''}">`;
  return `<div class="field"><label for="${id}">${f.l}${req}</label>${ctl}</div>`;
}
function crud(cfg) {
  let pg = 1; const form = $('#filters'), body = $('#tbl tbody');
  const rows = () => { const f = Object.fromEntries(new FormData(form)); return cfg.data.filter(r => cfg.match(r, f)); };
  function render() {
    const all = rows(), pages = Math.max(1, Math.ceil(all.length / cfg.size)); if (pg > pages) pg = pages;
    const sl = all.slice((pg - 1) * cfg.size, pg * cfg.size);
    body.innerHTML = sl.map(r => `<tr>${cfg.row(r)}<td><div class="act"><button data-a="view" data-id="${r.id}" title="View">👁</button><button data-a="edit" data-id="${r.id}" title="Edit">✏️</button><button data-a="del" data-id="${r.id}" title="Delete">🗑</button></div></td></tr>`).join('') || `<tr><td colspan="12" style="text-align:center;padding:30px">No records found</td></tr>`;
    $('#info').textContent = all.length ? `Showing ${(pg - 1) * cfg.size + 1} to ${(pg - 1) * cfg.size + sl.length} of ${all.length} ${cfg.name}` : `No ${cfg.name} found`;
    let p = '<button class="pg" data-p="1">«</button>';
    for (let i = 1; i <= pages; i++) p += `<button class="pg ${i === pg ? 'on' : ''}" data-p="${i}">${i}</button>`;
    $('#pages').innerHTML = p + `<button class="pg" data-p="${pages}">»</button>`;
    if (cfg.stats) $('#stats').innerHTML = cfg.stats();
  }
  function edit(rec) {
    const m = openModal(rec ? 'Edit ' + cfg.single : 'Add New ' + cfg.single, `<form id="mForm" class="grid2">${cfg.fields.map(f => formField(f, rec ? rec[f.n] : '')).join('')}<div style="grid-column:1/-1"><button class="btn block">${rec ? 'Update' : 'Save'} ${cfg.single}</button></div></form>`);
    bindForm($('#mForm', m), () => {
      const v = {}; cfg.fields.forEach(f => v[f.n] = (cfg.num || []).includes(f.n) ? Number($('#m_' + f.n).value) : $('#m_' + f.n).value.trim());
      if (rec) Object.assign(rec, v);
      else { const n = Math.max(...cfg.data.map(r => parseInt(r.id.replace(/\D/g, '')))) + 1; cfg.data.unshift({id: cfg.prefix + String(n).padStart(cfg.pad, '0'), ...(cfg.defaults || {}), ...v}); }
      closeModal(); render(); toast(`${cfg.single} ${rec ? 'updated' : 'added'} successfully`);
    });
  }
  form.addEventListener('submit', e => { e.preventDefault(); pg = 1; render(); });
  form.addEventListener('reset', () => setTimeout(() => { pg = 1; render(); }, 0));
  $('#pages').onclick = e => { const b = e.target.closest('[data-p]'); if (b) { pg = +b.dataset.p; render(); } };
  $('#addBtn').onclick = () => edit(null);
  body.onclick = e => {
    const b = e.target.closest('[data-a]'); if (!b) return;
    const r = cfg.data.find(x => x.id === b.dataset.id);
    if (b.dataset.a === 'edit') edit(r);
    if (b.dataset.a === 'view') openModal(cfg.single + ' Details', `<div class="dl">${Object.entries(cfg.view(r)).map(([k, v]) => `<div><span>${k}</span>${v}</div>`).join('')}</div>`);
    if (b.dataset.a === 'del' && confirm(`Delete ${cfg.single.toLowerCase()} ${r.id}?`)) { cfg.data.splice(cfg.data.indexOf(r), 1); render(); toast(cfg.single + ' deleted'); }
  };
  render();
}
const fillSel = (id, arr, first) => { $(id).innerHTML = `<option value="">${first}</option>` + [...new Set(arr)].sort().map(v => `<option>${v}</option>`).join(''); };
const has = (r, q, keys) => !q || keys.some(k => String(r[k]).toLowerCase().includes(q.toLowerCase()));

/* ---------- pages ---------- */
function pDashboard() {
  $('#kpis').innerHTML = kpi('🚗', 'Total Cars', 256, '12%') + kpi('📅', 'Total Bookings', 128, '8%') + kpi('🎯', 'Test Drives', 45, '15%') + kpi('👥', 'Total Customers', 320, '10%') + kpi('₹', 'Total Revenue', '₹ 18,75,000', '18%');
  const draw = () => { const w = $('#range').value === 'w'; lineChart($('#lineBox'), DAYS, [{n: 'Bookings', c: '#111', v: w ? [42,60,85,64,44,70,92] : [30,55,70,80,60,65,75]}, {n: 'Test Drives', c: '#888', v: w ? [22,38,60,37,32,41,50] : [18,30,45,50,35,40,48]}]); };
  $('#range').onchange = draw; draw();
  donut($('#donutBox'), STATUS_COUNTS, ['#111', '#444', '#888', '#ddd']);
  $('#rb').innerHTML = BOOKINGS.slice(0, 5).map(b => `<tr><td>${b.id}</td><td>${b.cust}</td><td>${b.car}</td><td>${fmtDate(b.bdate)}</td><td>${badge(b.status)}</td></tr>`).join('');
  $('#rt').innerHTML = TESTDRIVES.map(t => `<tr><td>${t.id}</td><td>${t.cust}</td><td>${t.car}</td><td>${fmtDate(t.date)}</td><td>${badge(t.status)}</td></tr>`).join('');
}
function pCars() {
  fillSel('#fBrand', CARS.map(c => c.brand), 'All Brands'); fillSel('#fFuel', CARS.map(c => c.fuel), 'All Fuel Types'); fillSel('#fStatus', ['Active', 'Inactive'], 'All Status');
  crud({data: CARS, size: 7, name: 'cars', single: 'Car', prefix: 'CAR', pad: 3, num: ['year', 'price', 'km'], defaults: {owner: '1st Owner', seats: 5},
    match: (r, f) => has(r, f.q, ['name', 'brand', 'id']) && (!f.brand || r.brand === f.brand) && (!f.fuel || r.fuel === f.fuel) && (!f.status || r.status === f.status),
    row: c => `<td>${c.id}</td><td><div class="thumb">🚗</div></td><td>${c.name}</td><td>${c.brand}</td><td>${c.year}</td><td>${c.fuel}</td><td>${c.trans}</td><td>${c.price.toLocaleString('en-IN')}</td><td>${badge(c.status)}</td>`,
    fields: [{n: 'name', l: 'Car Name', r: 'required minlen:3'}, {n: 'brand', l: 'Brand', r: 'required name'}, {n: 'year', l: 'Model Year', t: 'number', r: 'required number'}, {n: 'fuel', l: 'Fuel Type', o: ['Petrol', 'Diesel', 'CNG', 'Electric'], r: 'required'}, {n: 'trans', l: 'Transmission', o: ['Manual', 'Automatic'], r: 'required'}, {n: 'cat', l: 'Category', o: ['Hatchback', 'SUV', 'Sedan', 'Luxury', 'Sports'], r: 'required'}, {n: 'price', l: 'Price (₹)', t: 'number', r: 'required number'}, {n: 'km', l: 'Kilometres Driven', t: 'number', r: 'required number'}, {n: 'status', l: 'Status', o: ['Active', 'Inactive'], r: 'required'}],
    view: c => ({ID: c.id, Name: c.name, Brand: c.brand, Year: c.year, Fuel: c.fuel, Transmission: c.trans, Category: c.cat, Price: rupee(c.price), Driven: c.km.toLocaleString('en-IN') + ' km', Status: c.status})});
}
function pBookings() {
  fillSel('#fStatus', BOOKINGS.map(b => b.status), 'All Status'); fillSel('#fPay', BOOKINGS.map(b => b.pay), 'All Payment Status');
  crud({data: BOOKINGS, size: 8, name: 'bookings', single: 'Booking', prefix: 'BK', pad: 4, num: ['amount'], defaults: {bdate: new Date().toISOString().split('T')[0]},
    match: (r, f) => has(r, f.q, ['id', 'cust', 'car']) && (!f.status || r.status === f.status) && (!f.pay || r.pay === f.pay),
    row: b => `<td>${b.id}</td><td>${b.cust}</td><td>${b.car}</td><td>${fmtDate(b.bdate)}</td><td>${fmtDate(b.from)}</td><td>${fmtDate(b.to)}</td><td>${b.amount.toLocaleString('en-IN')}</td><td>${badge(b.pay)}</td><td>${badge(b.status)}</td>`,
    fields: [{n: 'cust', l: 'Customer Name', r: 'required name'}, {n: 'car', l: 'Car Model', o: CARS.map(c => c.name), r: 'required'}, {n: 'from', l: 'From Date', t: 'date', r: 'required'}, {n: 'to', l: 'To Date', t: 'date', r: 'required after:m_from'}, {n: 'amount', l: 'Total Amount (₹)', t: 'number', r: 'required number'}, {n: 'pay', l: 'Payment Status', o: ['Paid', 'Pending', 'Failed'], r: 'required'}, {n: 'status', l: 'Booking Status', o: ['Confirmed', 'Pending', 'Cancelled', 'Completed'], r: 'required'}],
    view: b => ({'Booking ID': b.id, Customer: b.cust, Car: b.car, 'Booking Date': fmtDate(b.bdate), From: fmtDate(b.from), To: fmtDate(b.to), Amount: rupee(b.amount), Payment: b.pay, Status: b.status}),
    stats: () => { const n = s => BOOKINGS.filter(b => b.status === s).length; return kpi('📅', 'Total Bookings', 128 + BOOKINGS.length - 8, '8%') + kpi('✅', 'Confirmed Bookings', 74 + n('Confirmed') - 5, '12%') + kpi('⏳', 'Pending Bookings', 32, '5%', 1) + kpi('❌', 'Cancelled Bookings', 13, '3%', 1) + kpi('₹', 'Total Revenue', '₹ 18,75,000', '18%'); }});
}
function pCustomers() {
  fillSel('#fStatus', ['Active', 'Inactive'], 'All Status'); fillSel('#fCity', CUSTOMERS.map(c => c.city), 'All Cities');
  crud({data: CUSTOMERS, size: 8, name: 'customers', single: 'Customer', prefix: 'CUST', pad: 3, num: [], defaults: {bookings: 0, drives: 0, date: new Date().toISOString().split('T')[0]},
    match: (r, f) => has(r, f.q, ['name', 'email', 'phone']) && (!f.status || r.status === f.status) && (!f.city || r.city === f.city),
    row: c => `<td>${c.id}</td><td><span class="avatar" style="width:30px;height:30px;display:inline-grid;color:#fff">${c.name[0]}</span> ${c.name}</td><td>${c.email}</td><td>${c.phone}</td><td>${c.city}</td><td>${c.bookings}</td><td>${c.drives}</td><td>${fmtDate(c.date)}</td><td>${badge(c.status)}</td>`,
    fields: [{n: 'name', l: 'Customer Name', r: 'required name'}, {n: 'email', l: 'Email', r: 'required email'}, {n: 'phone', l: 'Phone', t: 'tel', r: 'required phone'}, {n: 'city', l: 'City', r: 'required name'}, {n: 'status', l: 'Status', o: ['Active', 'Inactive'], r: 'required'}],
    view: c => ({ID: c.id, Name: c.name, Email: c.email, Phone: c.phone, City: c.city, Bookings: c.bookings, 'Test Drives': c.drives, Registered: fmtDate(c.date), Status: c.status}),
    stats: () => kpi('👥', 'Total Customers', 320 + CUSTOMERS.length - 8, '10%') + kpi('➕', 'New This Week', 28, '15%') + kpi('📅', 'Total Bookings', 128, '8%') + kpi('🎯', 'Total Test Drives', 45, '12%')});
}
function pReports() {
  $('#kpis').innerHTML = kpi('🚗', 'Total Cars', 256, '12%') + kpi('📅', 'Total Bookings', 128, '8%') + kpi('🎯', 'Total Test Drives', 45, '15%') + kpi('👥', 'Total Customers', 320, '10%') + kpi('₹', 'Total Revenue', '₹ 18,75,000', '18%');
  lineChart($('#trend'), DAYS, [{n: 'Bookings', c: '#1d4ed8', v: [40,60,85,65,45,70,90]}, {n: 'Test Drives', c: '#16a34a', v: [15,30,55,35,25,40,60]}]);
  lineChart($('#rev'), DAYS, [{n: 'Revenue', c: '#3b82f6', v: [6,8.2,12.4,8.3,6.8,10.2,13.9]}], {max: 15, area: true, legend: false, fmt: v => v + 'L'});
  donut($('#status'), STATUS_COUNTS, ['#1d4ed8', '#f59e0b', '#dc2626', '#16a34a']);
  $('#top').innerHTML = [['Toyota Innova Crysta', 28], ['Hyundai Creta', 22], ['Honda City', 18], ['Maruti Brezza', 15], ['Kia Seltos', 12]].map((t, i) => `<tr><td>${i + 1}</td><td>🚗 ${t[0]}</td><td>${t[1]}</td></tr>`).join('');
  const csv = () => { const h = ['Booking ID', 'Customer', 'Car', 'From', 'To', 'Amount', 'Payment', 'Status'];
    const out = [h, ...BOOKINGS.map(b => [b.id, b.cust, b.car, b.from, b.to, b.amount, b.pay, b.status])].map(r => r.map(v => `"${v}"`).join(',')).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([out], {type: 'text/csv'})); a.download = 'bookings-report.csv'; a.click(); toast('Report exported'); };
  $('#exportBtn').onclick = csv; $$('.rep button').forEach(b => b.onclick = csv);
}

/* ---------- admin login / register ---------- */
function pAuth() {
  bindForm($('#adminLogin'), () => { toast('Login successful'); setTimeout(() => location.href = 'dashboard.html', 800); });
  bindForm($('#adminReg'), () => { toast('Admin registered successfully'); setTimeout(() => location.href = 'login.html', 1000); });
}

if (document.body.classList.contains('admin')) adminLayout();
({dashboard: pDashboard, cars: pCars, bookings: pBookings, customers: pCustomers, reports: pReports, 'a-login': pAuth, 'a-register': pAuth})[apage]?.();
