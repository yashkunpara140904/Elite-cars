/* ===== JavaScript form validation =====
   Usage: add data-rules="required email" on an input, wrap it in <div class="field">
   Rules with arguments use a colon, e.g. match:password  minlen:10
   Rules implemented (min. 5 required): required, passlen, email, passpattern, phone (+ name, match, futuredate, after, number, minlen)  */
const EMAIL_RE = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;
const PHONE_RE = /^[6-9]\d{9}$/;
const PASS_RE  = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9\s]).+$/;
const NAME_RE  = /^[A-Za-z][A-Za-z .'-]{1,39}$/;

const RULES = {
  // 1. All fields are required
  required: (v, el, label) => (el.type === 'checkbox' ? el.checked : v.trim() !== '') || `${label} is required`,
  // 2. Password length (8 - 16 characters)
  passlen: v => !v || (v.length >= 8 && v.length <= 16) || 'Password must be 8 to 16 characters long',
  // 3. Email pattern
  email: v => !v || EMAIL_RE.test(v.trim()) || 'Enter a valid email address (e.g. name@example.com)',
  // 4. Password pattern
  passpattern: v => !v || PASS_RE.test(v) || 'Password needs an uppercase, a lowercase, a number and a special character',
  // 5. Phone number pattern
  phone: v => !v || PHONE_RE.test(v.trim()) || 'Mobile number must be 10 digits and start with 6, 7, 8 or 9',
  // extras
  name: v => !v || NAME_RE.test(v.trim()) || 'Use letters only (2 to 40 characters)',
  match: (v, el, l, id) => v === document.getElementById(id).value || 'Passwords do not match',
  minlen: (v, el, l, n) => !v || v.trim().length >= +n || `Minimum ${n} characters required`,
  number: v => !v || (!isNaN(v) && Number(v) > 0) || 'Enter a valid positive number',
  futuredate: v => { if (!v) return true; const t = new Date(); t.setHours(0,0,0,0); return new Date(v) >= t || 'Date cannot be in the past'; },
  after: (v, el, l, id) => { const o = document.getElementById(id).value; return !v || !o || new Date(v) >= new Date(o) || 'Must be on or after the start date'; }
};

function labelOf(el) {
  const f = el.closest('.field');
  const lb = f && f.querySelector('label');
  return el.dataset.label || (lb ? lb.textContent.replace('*', '').trim() : 'This field');
}
function validateField(el) {
  const field = el.closest('.field');
  if (!field || !el.dataset.rules) return true;
  let err = field.querySelector('.err');
  if (!err) { err = document.createElement('small'); err.className = 'err'; field.appendChild(err); }
  let msg = '';
  for (const r of el.dataset.rules.split(' ')) {
    const [name, arg] = r.split(':');
    const res = RULES[name](el.value, el, labelOf(el), arg);
    if (res !== true) { msg = res; break; }
  }
  field.classList.toggle('invalid', !!msg);
  field.classList.toggle('valid', !msg && el.value !== '');
  err.textContent = msg;
  return !msg;
}
function validateForm(form) {
  let first = null;
  $$('[data-rules]', form).forEach(el => { if (!validateField(el) && !first) first = el; });
  if (first) first.focus();
  return !first;
}
function bindForm(form, onValid) {
  if (!form) return;
  form.noValidate = true;
  $$('[data-rules]', form).forEach(el => {
    el.addEventListener('blur', () => validateField(el));
    el.addEventListener(el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'date' ? 'change' : 'input', () => {
      const f = el.closest('.field');
      if (f.classList.contains('invalid') || f.classList.contains('valid') || el.type === 'checkbox') validateField(el);
      $$('[data-rules*="match:' + el.id + '"]', form).forEach(m => { if (m.value) validateField(m); });
    });
  });
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (validateForm(form)) onValid(form);
    else toast('Please correct the highlighted fields', 'bad');
  });
  form.addEventListener('reset', () => setTimeout(() => $$('.field', form).forEach(f => { f.classList.remove('invalid', 'valid'); const e = f.querySelector('.err'); if (e) e.textContent = ''; }), 0));
}
