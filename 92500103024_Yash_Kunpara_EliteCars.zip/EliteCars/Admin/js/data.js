/* ===== Dummy data (front-end only, no backend) + shared helpers ===== */
const CARS = [
  {id:'CAR001',name:'Toyota Innova Crysta',brand:'Toyota',year:2021,fuel:'Diesel',trans:'Manual',price:1850000,km:45000,owner:'1st Owner',seats:7,cat:'SUV',status:'Active'},
  {id:'CAR002',name:'Honda City',brand:'Honda',year:2020,fuel:'Petrol',trans:'Automatic',price:1175000,km:35000,owner:'2nd Owner',seats:5,cat:'Sedan',status:'Active'},
  {id:'CAR003',name:'Hyundai Creta',brand:'Hyundai',year:2021,fuel:'Diesel',trans:'Manual',price:1420000,km:28000,owner:'1st Owner',seats:5,cat:'SUV',status:'Active'},
  {id:'CAR004',name:'Maruti Brezza',brand:'Maruti Suzuki',year:2022,fuel:'Petrol',trans:'Manual',price:834000,km:18000,owner:'1st Owner',seats:5,cat:'SUV',status:'Active'},
  {id:'CAR005',name:'Kia Seltos',brand:'Kia',year:2021,fuel:'Diesel',trans:'Automatic',price:1595000,km:30000,owner:'1st Owner',seats:5,cat:'SUV',status:'Inactive'},
  {id:'CAR006',name:'Tata Nexon',brand:'Tata',year:2022,fuel:'Petrol',trans:'Manual',price:910000,km:15000,owner:'1st Owner',seats:5,cat:'SUV',status:'Active'},
  {id:'CAR007',name:'Mahindra XUV700',brand:'Mahindra',year:2023,fuel:'Diesel',trans:'Automatic',price:2025000,km:9000,owner:'1st Owner',seats:7,cat:'SUV',status:'Active'},
  {id:'CAR008',name:'Toyota Fortuner',brand:'Toyota',year:2020,fuel:'Diesel',trans:'Automatic',price:3250000,km:52000,owner:'2nd Owner',seats:7,cat:'SUV',status:'Active'},
  {id:'CAR009',name:'Hyundai Verna',brand:'Hyundai',year:2022,fuel:'Petrol',trans:'Automatic',price:1290000,km:21000,owner:'1st Owner',seats:5,cat:'Sedan',status:'Active'},
  {id:'CAR010',name:'Maruti Baleno',brand:'Maruti Suzuki',year:2021,fuel:'Petrol',trans:'Manual',price:690000,km:33000,owner:'1st Owner',seats:5,cat:'Hatchback',status:'Active'},
  {id:'CAR011',name:'Tata Altroz',brand:'Tata',year:2022,fuel:'Diesel',trans:'Manual',price:780000,km:24000,owner:'1st Owner',seats:5,cat:'Hatchback',status:'Active'},
  {id:'CAR012',name:'BMW 3 Series',brand:'BMW',year:2020,fuel:'Petrol',trans:'Automatic',price:3890000,km:27000,owner:'1st Owner',seats:5,cat:'Luxury',status:'Active'},
  {id:'CAR013',name:'Ford Mustang',brand:'Ford',year:2019,fuel:'Petrol',trans:'Automatic',price:5400000,km:12000,owner:'2nd Owner',seats:4,cat:'Sports',status:'Active'},
  {id:'CAR014',name:'Kia Sonet',brand:'Kia',year:2022,fuel:'Petrol',trans:'Manual',price:985000,km:14000,owner:'1st Owner',seats:5,cat:'SUV',status:'Active'}
];
const BOOKINGS = [
  {id:'BK1001',cust:'Rahul Sharma',car:'Toyota Innova Crysta',bdate:'2026-05-20',from:'2026-05-25',to:'2026-05-28',amount:18500,pay:'Paid',status:'Confirmed'},
  {id:'BK1002',cust:'Priya Patel',car:'Honda City',bdate:'2026-05-20',from:'2026-05-22',to:'2026-05-24',amount:7800,pay:'Pending',status:'Pending'},
  {id:'BK1003',cust:'Arjun Mehta',car:'Hyundai Creta',bdate:'2026-05-19',from:'2026-05-21',to:'2026-05-23',amount:9600,pay:'Paid',status:'Confirmed'},
  {id:'BK1004',cust:'Neha Verma',car:'Maruti Brezza',bdate:'2026-05-19',from:'2026-05-26',to:'2026-05-27',amount:4200,pay:'Paid',status:'Confirmed'},
  {id:'BK1005',cust:'Karan Singh',car:'Kia Seltos',bdate:'2026-05-18',from:'2026-05-20',to:'2026-05-21',amount:6100,pay:'Pending',status:'Pending'},
  {id:'BK1006',cust:'Sneha Iyer',car:'Toyota Fortuner',bdate:'2026-05-18',from:'2026-05-24',to:'2026-05-26',amount:21000,pay:'Paid',status:'Confirmed'},
  {id:'BK1007',cust:'Vivek Nair',car:'Hyundai Verna',bdate:'2026-05-17',from:'2026-05-19',to:'2026-05-20',amount:5300,pay:'Failed',status:'Cancelled'},
  {id:'BK1008',cust:'Manish Gupta',car:'Honda City',bdate:'2026-05-17',from:'2026-05-23',to:'2026-05-24',amount:7800,pay:'Paid',status:'Confirmed'}
];
const CUSTOMERS = [
  {id:'CUST001',name:'Rahul Sharma',email:'rahul.sharma@email.com',phone:'9876543210',city:'Mumbai',bookings:5,drives:2,date:'2026-05-20',status:'Active'},
  {id:'CUST002',name:'Priya Patel',email:'priya.patel@email.com',phone:'9876543211',city:'Ahmedabad',bookings:3,drives:1,date:'2026-05-19',status:'Active'},
  {id:'CUST003',name:'Arjun Mehta',email:'arjun.mehta@email.com',phone:'9876543212',city:'Pune',bookings:4,drives:3,date:'2026-05-19',status:'Active'},
  {id:'CUST004',name:'Neha Verma',email:'neha.verma@email.com',phone:'9876543213',city:'Delhi',bookings:2,drives:1,date:'2026-05-18',status:'Active'},
  {id:'CUST005',name:'Karan Singh',email:'karan.singh@email.com',phone:'9876543214',city:'Jaipur',bookings:6,drives:2,date:'2026-05-18',status:'Active'},
  {id:'CUST006',name:'Sneha Iyer',email:'sneha.iyer@email.com',phone:'9876543215',city:'Bangalore',bookings:1,drives:1,date:'2026-05-17',status:'Inactive'},
  {id:'CUST007',name:'Vivek Nair',email:'vivek.nair@email.com',phone:'9876543216',city:'Kochi',bookings:2,drives:0,date:'2026-05-17',status:'Active'},
  {id:'CUST008',name:'Manish Gupta',email:'manish.gupta@email.com',phone:'9876543217',city:'Hyderabad',bookings:3,drives:2,date:'2026-05-16',status:'Active'}
];
const TESTDRIVES = [
  {id:'TD1001',cust:'Sneha Iyer',car:'Toyota Fortuner',date:'2026-05-20',status:'Scheduled'},
  {id:'TD1002',cust:'Vivek Nair',car:'Hyundai Verna',date:'2026-05-20',status:'Pending'},
  {id:'TD1003',cust:'Manish Gupta',car:'Honda City',date:'2026-05-19',status:'Completed'},
  {id:'TD1004',cust:'Pooja Reddy',car:'Kia Sonet',date:'2026-05-18',status:'Scheduled'},
  {id:'TD1005',cust:'Ankit Jain',car:'Maruti Baleno',date:'2026-05-18',status:'Pending'}
];

/* ----- helpers ----- */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const rupee = n => '₹ ' + Number(n).toLocaleString('en-IN');
const fmtDate = iso => new Date(iso).toLocaleDateString('en-GB', {day:'numeric', month:'short', year:'numeric'});
const badgeClass = s => ({Active:'ok',Paid:'ok',Confirmed:'ok',Completed:'info',Scheduled:'info',Pending:'warn',Inactive:'bad',Failed:'bad',Cancelled:'bad'}[s] || 'info');
const badge = s => `<span class="badge ${badgeClass(s)}">${s}</span>`;
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function toast(msg, type = 'ok') {
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const t = document.createElement('div');
  t.className = 'toast ' + type; t.textContent = msg; box.appendChild(t);
  setTimeout(() => t.remove(), 3200);
}
function openModal(title, html) {
  closeModal();
  const m = document.createElement('div');
  m.className = 'modal-bg'; m.id = 'modal';
  m.innerHTML = `<div class="modal"><div class="modal-head"><h3>${title}</h3><button class="x" aria-label="Close">&times;</button></div><div class="modal-body">${html}</div></div>`;
  document.body.appendChild(m);
  m.addEventListener('click', e => { if (e.target === m || e.target.classList.contains('x')) closeModal(); });
  return m;
}
function closeModal() { const m = $('#modal'); if (m) m.remove(); }
