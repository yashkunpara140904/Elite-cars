/* ===== Client-side page logic ===== */
const params = new URLSearchParams(location.search);
const page = document.body.dataset.page;
const carIcon = '<div class="ph"><span>🚗</span></div>';
const SPECS = c => ({
  Engine: c.fuel === 'Diesel' ? '2393 cc' : '1498 cc', Power: c.fuel === 'Diesel' ? '150 bhp' : '121 bhp',
  Torque: c.fuel === 'Diesel' ? '343 Nm' : '145 Nm', Mileage: c.fuel === 'Diesel' ? '16.5 kmpl' : '17.8 kmpl',
  'Fuel Tank Capacity': '55 Liters', 'Seating Capacity': c.seats + ' Seater', 'Boot Space': '300 Liters', 'Ground Clearance': '178 mm'
});

/* ---------- HOME ---------- */
function initHome() {
  const f = $('#homeSearch');
  f.addEventListener('submit', e => {
    const min = +f.min.value, max = +f.max.value;
    if (f.min.value && f.max.value && min > max) { e.preventDefault(); toast('Min price cannot be greater than max price', 'bad'); }
  });
}

/* ---------- INVENTORY ---------- */
function initInventory() {
  const f = $('#filterForm'), size = 6; let pg = 1; const fav = new Set();
  const uniq = k => [...new Set(CARS.map(c => c[k]))].sort();
  const fill = (id, arr, first) => { $(id).innerHTML = `<option value="">${first}</option>` + arr.map(v => `<option>${v}</option>`).join(''); };
  fill('#fCat', uniq('cat'), 'All Categories'); fill('#fBrand', uniq('brand'), 'All Brands');
  fill('#fFuel', uniq('fuel'), 'All Fuel Types'); fill('#fTrans', uniq('trans'), 'All');
  const yrs = Array.from({length: 10}, (_, i) => 2015 + i);
  fill('#fMinY', yrs, 'Min Year'); fill('#fMaxY', yrs, 'Max Year');
  if (params.get('cat')) f.cat.value = params.get('cat');
  if (params.get('fuel')) f.fuel.value = params.get('fuel');
  if (params.get('q')) $('#q').value = params.get('q');
  if (params.get('min')) f.min.value = params.get('min');
  if (params.get('max')) f.max.value = params.get('max');

  function list() {
    const q = $('#q').value.toLowerCase().trim();
    let r = CARS.filter(c => c.status === 'Active' &&
      (!q || (c.name + ' ' + c.brand + ' ' + c.cat).toLowerCase().includes(q)) &&
      (!f.cat.value || c.cat === f.cat.value) && (!f.brand.value || c.brand === f.brand.value) &&
      (!f.fuel.value || c.fuel === f.fuel.value) && (!f.trans.value || c.trans === f.trans.value) &&
      (!f.min.value || c.price >= +f.min.value) && (!f.max.value || c.price <= +f.max.value) &&
      (!f.minY.value || c.year >= +f.minY.value) && (!f.maxY.value || c.year <= +f.maxY.value));
    const s = $('#sort').value;
    if (s === 'new') r.sort((a, b) => b.year - a.year);
    if (s === 'low') r.sort((a, b) => a.price - b.price);
    if (s === 'high') r.sort((a, b) => b.price - a.price);
    return r;
  }
  function render() {
    const r = list(), pages = Math.max(1, Math.ceil(r.length / size)); if (pg > pages) pg = pages;
    const slice = r.slice((pg - 1) * size, pg * size);
    $('#count').textContent = r.length ? `Showing ${(pg - 1) * size + 1} to ${(pg - 1) * size + slice.length} of ${r.length} cars` : 'No cars match your filters';
    $('#cars').innerHTML = slice.map(c => `<article class="car-row">
      <div class="img">${carIcon}<button class="heart ${fav.has(c.id) ? 'on' : ''}" data-id="${c.id}" aria-label="Wishlist">${fav.has(c.id) ? '♥' : '♡'}</button></div>
      <div class="info"><h3>${c.name}</h3>
        <ul class="meta"><li>⛽ ${c.fuel}</li><li>⚙️ ${c.trans}</li><li>💺 ${c.seats} Seater</li><li>📅 ${c.year}</li><li>🛣️ ${c.km.toLocaleString('en-IN')} km</li><li>🏷️ ${c.owner}</li></ul>
        <span class="tag">${c.cat}</span></div>
      <div class="side"><div class="price">${rupee(c.price)}</div>
        <a class="btn" href="car-details.html?id=${c.id}">View Details</a><a class="btn light" href="test-drive.html?id=${c.id}">Book Test Drive</a></div></article>`).join('');
    let p = '';
    for (let i = 1; i <= pages; i++) p += `<button class="pg ${i === pg ? 'on' : ''}" data-p="${i}">${i}</button>`;
    $('#pager').innerHTML = p + `<button class="pg" data-p="${Math.min(pg + 1, pages)}">Next ›</button><button class="pg" data-p="${pages}">Last »</button>`;
  }
  f.addEventListener('submit', e => { e.preventDefault(); if (f.min.value && f.max.value && +f.min.value > +f.max.value) return toast('Min price cannot be greater than max price', 'bad'); pg = 1; render(); });
  f.addEventListener('reset', () => setTimeout(() => { pg = 1; render(); }, 0));
  $('#q').addEventListener('input', () => { pg = 1; render(); });
  $('#sort').addEventListener('change', render);
  $('#pager').addEventListener('click', e => { const b = e.target.closest('[data-p]'); if (b) { pg = +b.dataset.p; render(); scrollTo({top: 0, behavior: 'smooth'}); } });
  $('#cars').addEventListener('click', e => { const h = e.target.closest('.heart'); if (!h) return; fav.has(h.dataset.id) ? fav.delete(h.dataset.id) : fav.add(h.dataset.id); toast(fav.has(h.dataset.id) ? 'Added to wishlist' : 'Removed from wishlist'); render(); });
  render();
}

/* ---------- CAR DETAILS ---------- */
function initDetails() {
  const c = CARS.find(x => x.id === params.get('id')) || CARS[0];
  const sp = SPECS(c);
  const specHtml = Object.entries(sp).map(([k, v]) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`).join('');
  const feats = ['ABS with EBD', 'Dual Airbags', 'Rear Camera', 'Touchscreen Infotainment', 'Cruise Control', 'Alloy Wheels', 'Keyless Entry', 'Climate Control'];
  const tabs = {
    Overview: `<p>The ${c.name} is the perfect blend of performance, comfort and reliability. With a powerful ${c.fuel.toLowerCase()} engine, spacious interiors and advanced safety features, it is designed to make every journey comfortable and memorable.</p><ul class="chips">${feats.slice(0, 5).map(x => `<li>✔ ${x}</li>`).join('')}</ul>`,
    Specifications: `<div class="specs one">${specHtml}</div>`,
    Features: `<ul class="chips">${feats.map(x => `<li>✔ ${x}</li>`).join('')}</ul>`,
    Documents: `<p>✔ RC Book verified &nbsp; ✔ Insurance valid till 15 Aug 2027 &nbsp; ✔ Service history available</p>`,
    'Reviews (120)': `<p>⭐ 4.6 average rating from 120 verified buyers.</p><p><i>"Smooth drive, great comfort and excellent value for money."</i> – Verified Buyer</p>`
  };
  $('#detail').innerHTML = `
  <p class="crumb"><a href="index.html">Home</a> › <a href="inventory.html">Inventory</a> › Car Details</p>
  <div class="d-top">
    <div><div class="gallery">${carIcon}<button class="arrow l">‹</button><button class="arrow r">›</button></div>
      <div class="thumbs">${[0,1,2,3,4,5].map(i => `<div class="th ${i ? '' : 'on'}">🚗</div>`).join('')}</div></div>
    <div class="d-info"><h1>${c.name}</h1>
      <p class="meta2">⛽ ${c.fuel} &nbsp; ⚙️ ${c.trans} &nbsp; 💺 ${c.seats} Seater</p>
      <p>★ 4.6 (120 Reviews) &nbsp;|&nbsp; <a href="#" id="cmp">＋ Add to Compare</a></p><hr>
      ${[['Year', c.year], ['Driven', c.km.toLocaleString('en-IN') + ' km'], ['Fuel Type', c.fuel], ['Transmission', c.trans], ['Owner', c.owner], ['Registration', 'KA-01-AB-1234'], ['Insurance Validity', '15 Aug 2027'], ['Location', 'Bangalore, Karnataka']].map(([k, v]) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`).join('')}</div>
    <aside class="buy card"><small>Price</small><div class="price big">${rupee(c.price)}</div><small>(Inclusive of all taxes)</small>
      <a class="btn" href="test-drive.html?id=${c.id}">📅 Book Test Drive</a>
      <button class="btn light" data-t="Callback requested. We will call you soon.">📞 Request a Callback</button>
      <button class="btn light" data-t="EMI starts at ${rupee(Math.round(c.price * 0.9 / 60 * 1.15))}/month (60 months, indicative)">🧮 Check Finance Options</button>
      <button class="btn light" data-t="Brochure download started (demo)">⬇ Download Brochure</button>
      <button class="btn light" data-t="Added to wishlist">♡ Add to Wishlist</button></aside>
  </div>
  <div class="d-bottom"><div class="card"><div class="tabs">${Object.keys(tabs).map((t, i) => `<button class="${i ? '' : 'on'}" data-tab="${t}">${t}</button>`).join('')}</div><div id="tabBody" class="tabbody">${tabs.Overview}</div></div>
    <div class="card"><h3>Specifications</h3><div class="specs">${specHtml}</div></div></div>`;
  $$('.tabs button').forEach(b => b.onclick = () => { $$('.tabs button').forEach(x => x.classList.remove('on')); b.classList.add('on'); $('#tabBody').innerHTML = tabs[b.dataset.tab]; });
  $$('[data-t]').forEach(b => b.onclick = () => toast(b.dataset.t));
  $$('.th').forEach(t => t.onclick = () => { $$('.th').forEach(x => x.classList.remove('on')); t.classList.add('on'); });
  $('#cmp').onclick = e => { e.preventDefault(); toast('Added to compare'); };
}

/* ---------- TEST DRIVE ---------- */
function initTestDrive() {
  const sel = $('#carSel');
  sel.innerHTML = CARS.filter(c => c.status === 'Active').map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  if (params.get('id')) sel.value = params.get('id');
  const show = () => { const c = CARS.find(x => x.id === sel.value) || CARS[0]; $('#carBox').innerHTML = `${carIcon}<div><h3>${c.name}</h3><p>⛽ ${c.fuel}</p><p>⚙️ ${c.trans}</p><p>💺 ${c.seats} Seater</p><div class="price">${rupee(c.price)}</div></div>`; };
  sel.onchange = show; show();
  $('#tdDate').min = new Date().toISOString().split('T')[0];
  $('#tdTime').innerHTML = '<option value="">Select time</option>' + ['10:00 AM','11:00 AM','12:00 PM','02:00 PM','03:00 PM','04:00 PM','05:00 PM'].map(t => `<option>${t}</option>`).join('');
  $('#chLoc').onclick = () => toast('Only Bangalore, Karnataka is available right now');
  bindForm($('#tdForm'), f => {
    f.closest('.card').innerHTML = `<div class="success"><div class="tick">✔</div><h2>Request Submitted!</h2><p>Thank you, ${esc($('#tdName').value)}. Our executive will contact you on ${esc($('#tdMobile').value)} to confirm your test drive on ${fmtDate($('#tdDate').value)} at ${esc($('#tdTime').value)}.</p><a class="btn" href="inventory.html">Back to Inventory</a></div>`;
    scrollTo({top: 0, behavior: 'smooth'});
  });
}

/* ---------- CONTACT ---------- */
function initContact() {
  bindForm($('#contactForm'), f => { toast('Message sent! We reply within 24 hours.'); f.reset(); });
}

/* ---------- LOGIN / REGISTER (client) ---------- */
function initAuth() {
  const go = name => { try { localStorage.setItem('elitecars_user', name); } catch (e) {} toast('Success! Redirecting...'); setTimeout(() => location.href = 'index.html', 1000); };
  bindForm($('#loginForm'), f => go($('#email').value.split('@')[0]));
  bindForm($('#regForm'), f => go($('#firstName').value));
}

function initBookings() {
  $('#bkBody').innerHTML = BOOKINGS.slice(0, 4).map(b => `<tr><td>${b.id}</td><td>${b.car}</td><td>${fmtDate(b.from)}</td><td>${fmtDate(b.to)}</td><td>${rupee(b.amount)}</td><td>${badge(b.status)}</td></tr>`).join('');
}

({home: initHome, bookings: initBookings, inventory: initInventory, details: initDetails, testdrive: initTestDrive, contact: initContact, login: initAuth, register: initAuth})[page]?.();
