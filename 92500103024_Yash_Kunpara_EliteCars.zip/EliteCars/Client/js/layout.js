/* ===== Client-side shared header + footer (injected on every page) ===== */
const NAV = [['index.html','Home','home'],['inventory.html','Inventory','inventory'],['services.html','Services','services'],['bookings.html','Bookings','bookings'],['about.html','About Us','about'],['contact.html','Contact Us','contact']];
const LOGO = `<a class="logo" href="index.html"><span class="logo-ic">🚗</span><span><b>ELITE</b><small>CARS</small></span></a>`;

function currentUser() { try { return localStorage.getItem('elitecars_user'); } catch (e) { return null; } }

function renderLayout() {
  const page = document.body.dataset.page;
  const user = currentUser();
  const auth = user
    ? `<span class="hello">Hi, ${esc(user)}</span><button class="btn light sm" id="logoutBtn">Logout</button>`
    : `<a class="btn light" href="login.html">👤 Login / Register</a>`;
  const header = document.createElement('header');
  header.className = 'site';
  header.innerHTML = `<div class="container bar">${LOGO}
    <button class="burger" id="burger" aria-label="Menu">☰</button>
    <nav id="nav">${NAV.map(n => `<a href="${n[0]}" class="${n[2] === page ? 'active' : ''}">${n[1]}</a>`).join('')}</nav>
    <div class="hdr-auth">${auth}</div></div>`;
  document.body.prepend(header);

  const footer = document.createElement('footer');
  footer.className = 'site';
  footer.innerHTML = `<div class="container fgrid">
    <div>${LOGO}<p>Your trusted partner in car management. Manage, track &amp; maintain your cars with ease.</p></div>
    <div><h4>Quick Links</h4>${NAV.slice(0,5).map(n => `<a href="${n[0]}">${n[1]}</a>`).join('')}</div>
    <div><h4>Useful Links</h4><a href="#">Terms &amp; Conditions</a><a href="#">Privacy Policy</a><a href="#">Refund Policy</a><a href="#">FAQ</a></div>
    <div><h4>Contact Us</h4><p>📞 +91 98765 43210</p><p>✉️ info@elitecars.com</p><p>📍 123, Auto Street, Mumbai, India - 400001</p></div>
    <div><h4>Newsletter</h4><p>Subscribe to get the latest updates and offers.</p>
      <form class="news" id="newsForm"><div class="field"><input id="newsEmail" type="text" placeholder="Enter your email" data-rules="required email" data-label="Email"><button class="btn sm">➤</button></div></form>
      <div class="social"><a href="#">f</a><a href="#">in</a><a href="#">t</a><a href="#">▶</a></div></div>
  </div><div class="copy">© 2026 Elite Cars. All Rights Reserved.</div>`;
  document.body.appendChild(footer);

  $('#burger').onclick = () => $('#nav').classList.toggle('open');
  const lo = $('#logoutBtn');
  if (lo) lo.onclick = () => { try { localStorage.removeItem('elitecars_user'); } catch (e) {} location.reload(); };
  bindForm($('#newsForm'), f => { toast('Subscribed successfully!'); f.reset(); });
}
renderLayout();
